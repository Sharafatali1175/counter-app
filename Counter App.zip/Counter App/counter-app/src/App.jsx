import { useReducer } from 'react'
import './App.css'
import './bootstrap-style.css'

const initialState = 0;

const reducer = (state, action) => {
  switch (action.type) {
    case "Increment":
      return state + 1;
    case "Decrement":
      return state - 1;
    case "Reset":
      return 0;
    default:
      return state;
  }
}

function App() {
  const [count, dispatch] = useReducer(reducer, initialState)

  return (
    <div className="container counter-container text-center mt-5">
      <h1 className="mb-4">Count: <span className="text-primary">{count}</span></h1>
      <div className="row justify-content-center">
        <div className="col-xl-6 col-lg-6 col-md-6 mb-2">
          <button 
            className="btn btn-danger w-100 counter-button"
            onClick={() => dispatch({ type: "Decrement" })}
          >
            Decrement
          </button>
        </div>
        <div className="col-xl-6 col-lg-6 col-md-6 mb-2">
          <button 
            className="btn btn-success w-100 counter-button"
            onClick={() => dispatch({ type: "Increment" })}
          >
            Increment
          </button>
        </div>
        <div className="col-12 col-md-6 mt-2">
          <button 
            className="btn btn-secondary w-100 counter-button text-shadow"
            onClick={() => dispatch({ type: "Reset" })}
          >
            Reset
          </button>
        </div>
      </div>
    </div>
  )
}

export default App;
